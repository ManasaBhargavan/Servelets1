package com.cg.service;

import com.cg.dto.BillDTO;
import com.cg.exception.BillUserException;

public interface IBillService{
	public String insert(BillDTO billDTO)throws BillUserException;
}
